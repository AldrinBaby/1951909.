<?php

$sname= "localhost";
$unmae= "manjith";
$password = "123456";

$db_name = "test_db";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
	echo "Connection failed!";
}